// src/app/app-routing.module.ts
import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { LoginComponent }             from './components/login/login.component';
import { RegisterComponent }          from './components/register/register.component';
import { GroupsComponent }            from './components/groups/groups.component';
import { GroupDetailComponent }       from './components/group-detail/group-detail.component';
import { GroupCreateComponent }       from './components/group-create/group-create.component';
import { MyGroupsComponent }          from './components/my-groups/my-groups.component';
import { MyPrivateGroupsComponent }   from './components/my-private-groups/my-private-groups.component';
import { ProfileComponent }           from './components/profile/profile.component';
import { PostsComponent }             from './components/posts/posts.component';
import { AdminGuard }                 from './guards/admin-auth.guard';

const routes: Routes = [
  // --- Rutas Públicas ---
  { path: 'login',             component: LoginComponent },
  { path: 'register',          component: RegisterComponent },
  { path: 'groups',            component: GroupsComponent },
  { path: 'groups/:id',        component: GroupDetailComponent },
  { path: 'create-group',      component: GroupCreateComponent },
  { path: 'my-groups',         component: MyGroupsComponent },
  { path: 'my-private-groups', component: MyPrivateGroupsComponent },
  { path: 'profile',           component: ProfileComponent },
  { path: 'posts',             component: PostsComponent },

  // --- Lazy‑load Admin Module protegido por AdminGuard ---
  {
    path: 'admin',
    canActivate: [AdminGuard],
    loadChildren: () =>
      import('./admin/admin.module').then(m => m.AdminModule)
  },

  // --- Redirects por defecto ---
  { path: '',   redirectTo: 'groups', pathMatch: 'full' },
  { path: '**', redirectTo: 'groups' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
