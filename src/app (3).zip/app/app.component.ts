// src/app/app.component.ts
import { Component, OnInit, OnDestroy } from '@angular/core';
import { AuthService, User }            from './services/auth.service';
import { Router, NavigationEnd, Event } from '@angular/router';
import { Subscription }                 from 'rxjs';
import { filter }                       from 'rxjs/operators';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, OnDestroy {
  isLoggedIn    = false;
  defaultProfile = 'assets/default-profile.png';
  showHeader    = true;
  private subs  = new Subscription();

  constructor(
    private auth: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    // 1) Suscribirse a cambios de autenticación
    this.subs.add(
      this.auth.isAuthenticated$.subscribe(logged => {
        this.isLoggedIn = logged;
        if (!logged) {
          this.defaultProfile = 'assets/default-profile.png';
          return;
        }
        // Carga la info del usuario cuando esté logueado
        this.subs.add(
          this.auth.currentUser$.subscribe((user: User|null) => {
            this.defaultProfile = user?.profile_photo || 'assets/default-profile.png';
          })
        );
      })
    );

    // 2) Mostrar/ocultar el header según la ruta (oculta en /admin/**)
    this.subs.add(
      this.router.events
        .pipe(
          filter((e: Event): e is NavigationEnd => e instanceof NavigationEnd)
        )
        .subscribe((e: NavigationEnd) => {
          this.showHeader = !e.urlAfterRedirects.startsWith('/admin');
        })
    );
  }

  ngOnDestroy(): void {
    this.subs.unsubscribe();
  }

  logout(): void {
    this.auth.logout().subscribe({
      next: () => this.router.navigate(['/login']),
      error: err => console.error('Error en logout:', err)
    });
  }
}
