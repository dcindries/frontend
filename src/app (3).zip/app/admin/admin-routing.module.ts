import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminLayoutComponent }  from './layout/admin-layout.component';

const routes: Routes = [
  {
    path: '',
    component: AdminLayoutComponent,
    children: [
      // Redirect al cargar /admin → /admin/users
      { path: '',       redirectTo: 'users', pathMatch: 'full' },
      { path: 'users',  loadChildren: () => import('./users/users.module').then(m => m.UsersModule) },
      // Descomenta o añade más módulos aquí cuando los tengas:
      // { path: 'groups',   loadChildren: () => import('./groups/groups.module').then(m => m.GroupsModule) },
      // { path: 'posts',    loadChildren: () => import('./posts/posts.module').then(m => m.PostsModule) },
      // { path: 'comments', loadChildren: () => import('./comments/comments.module').then(m => m.CommentsModule) },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule {}
