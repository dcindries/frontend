import { Component } from '@angular/core';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent {
  menuItems = [
    { label: 'Usuarios', route: '/admin/users' },
    { label: 'Grupos',   route: '/admin/groups' },
    { label: 'Publicaciones', route: '/admin/posts' },
    { label: 'Comentarios',    route: '/admin/comments' }
  ];
}