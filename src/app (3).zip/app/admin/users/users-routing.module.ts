// src/app/admin/users/users-routing.module.ts
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UsersComponent }       from './users.component';
import { ListUserComponent }    from './list-users/list-user.component';
import { CreateUserComponent }  from './create-user/create-user.component';
import { EditUserComponent }    from './edit-user/edit-user.component';

const routes: Routes = [
  {
    path: '',
    component: UsersComponent,
    children: [
      { path: '',         component: ListUserComponent  }, // /admin/users
      { path: 'create',   component: CreateUserComponent}, // /admin/users/create
      { path: 'edit/:id', component: EditUserComponent  }  // /admin/users/edit/123
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UsersRoutingModule {}
