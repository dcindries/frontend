// src/app/app.module.ts
import { BrowserModule } from '@angular/platform-browser';
import { NgModule }      from '@angular/core';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ReactiveFormsModule }                 from '@angular/forms';

import { AppRoutingModule }    from './app-routing.module';
import { TokenInterceptor }    from './services/token.interceptor';

import { AppComponent }            from './app.component';
import { LoginComponent }          from './components/login/login.component';
import { RegisterComponent }       from './components/register/register.component';
import { GroupsComponent }         from './components/groups/groups.component';
import { GroupDetailComponent }    from './components/group-detail/group-detail.component';
import { GroupCreateComponent }    from './components/group-create/group-create.component';
import { MyGroupsComponent }       from './components/my-groups/my-groups.component';
import { MyPrivateGroupsComponent }from './components/my-private-groups/my-private-groups.component';
import { ProfileComponent }        from './components/profile/profile.component';
import { PostsComponent }          from './components/posts/posts.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    GroupsComponent,
    GroupDetailComponent,
    GroupCreateComponent,
    MyGroupsComponent,
    MyPrivateGroupsComponent,
    ProfileComponent,
    PostsComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    ReactiveFormsModule,
    AppRoutingModule        
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: TokenInterceptor,
      multi: true
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
