import { Component, OnInit } from '@angular/core';
import { AuthService } from './services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  isLoggedIn: boolean = false;
  user: any = null;
  defaultProfile: string = 'assets/default-profile.png'; // Imagen por defecto en la carpeta assets

  constructor(private authService: AuthService, private router: Router) {}

  ngOnInit(): void {
    // Suscribirse al estado de autenticación
    this.authService.isAuthenticated$.subscribe(auth => {
      this.isLoggedIn = auth;
      if (auth) {
        // Obtener los datos del usuario
        this.authService.getUser().subscribe({
          next: (user) => {
            this.defaultProfile = user.profile_photo ? user.profile_photo : 'assets/default-profile.png';
          },
          error: (err) => {
            console.error('Error al obtener usuario:', err);
            this.defaultProfile = 'assets/default-profile.png';
          }
        });
      } else {
        this.defaultProfile = 'assets/default-profile.png';
      }
    });
  }

  logout(): void {
    this.authService.logout().subscribe({
      next: (res) => {
        localStorage.removeItem('authToken');
        this.authService.setAuthentication(false);
        this.router.navigate(['/login']);
      },
      error: (err) => {
        console.error('Error en logout:', err);
      }
    });
  }
}
