import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  user: any;
  errorMessage: string = '';
  defaultProfile: string = 'assets/default-profile.png';
  selectedFile: File | null = null;
  previewUrl: string | ArrayBuffer | null = null;
  imageTimestamp: number = Date.now();
  isLoggedIn: boolean = false;

  constructor(private authService: AuthService, private fb: FormBuilder, private router: Router) {}

  ngOnInit(): void {
    this.loadUser();
  }

  loadUser(): void {
    this.authService.getUser().subscribe({
      next: (data) => {
        this.user = data;
        this.isLoggedIn = true;
        this.imageTimestamp = this.user?.updated_at ? new Date(this.user.updated_at).getTime() : this.imageTimestamp;
        console.log('Datos del usuario actualizados:', this.user);
      },
      error: (err) => {
        console.error('Error al obtener datos del usuario:', err);
        this.errorMessage = 'No se pudieron cargar los datos del usuario.';
      }
    });
  }

  onFileSelected(event: any): void {
    if (event.target.files && event.target.files.length > 0) {
      this.selectedFile = event.target.files[0];
      const reader = new FileReader();
      reader.onload = () => {
        this.previewUrl = reader.result;
      };
      reader.readAsDataURL(this.selectedFile!);
      console.log('Archivo seleccionado:', this.selectedFile);
    }
  }
  
  updateProfilePhoto(): void {
    if (!this.selectedFile) {
      this.errorMessage = 'Debes seleccionar una imagen.';
      return;
    }
    const formData = new FormData();
    formData.append('profile_photo', this.selectedFile);
    formData.append('_method', 'PUT'); // Para method spoofing, si es necesario
   
    this.authService.updateProfile(formData).subscribe({
      next: (res) => {
        console.log('Foto de perfil actualizada:', res);
        this.user = res;
        this.imageTimestamp = new Date().getTime();
        this.selectedFile = null;
        this.previewUrl = null;
      },
      error: (err) => {
        console.error('Error al actualizar foto de perfil:', err);
        this.errorMessage = err.error?.message || 'Error al actualizar la foto de perfil.';
      }
    });
  }

  logout(): void {
    this.authService.logout().subscribe({
      next: () => {
        // Actualiza el estado de autenticación y redirige
        localStorage.removeItem('authToken');
        this.router.navigate(['/login']);
      },
      error: (err) => console.error('Error al cerrar sesión:', err)
    });
  }
  
  get profileImageUrl(): string {
    const base = this.user && this.user.profile_photo ? this.user.profile_photo : this.defaultProfile;
    return `${base}?v=${this.imageTimestamp}`;
  }
}
