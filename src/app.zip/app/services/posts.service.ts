import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class PostsService {
  private apiUrl = environment.apiUrl;

  constructor(private http: HttpClient) { }

  // Obtener todos los posts
  getPosts(): Observable<any> {
    return this.http.get(`${this.apiUrl}/posts`);
  }

  // Obtener posts filtrados por group_id
  getPostsByGroup(groupId: number): Observable<any> {
    return this.http.get(`${this.apiUrl}/posts?group_id=${groupId}`);
  }


  createPost(postData: FormData): Observable<any> {
    const token = localStorage.getItem('authToken');
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
    return this.http.post(`${this.apiUrl}/posts`, postData, { headers });
  }
  
  // Actualizar y eliminar posts (métodos omitidos por brevedad)
  updatePost(id: number, postData: any): Observable<any> {
    return this.http.put(`${this.apiUrl}/posts/${id}`, postData);
  }

  deletePost(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/posts/${id}`);
  }

  updateProfile(data: FormData): Observable<any> {
    return this.http.put(`${this.apiUrl}/user`, data);
  }
  
}
