import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { GroupsComponent } from './components/groups/groups.component';
import { GroupDetailComponent } from './components/group-detail/group-detail.component';
import { GroupCreateComponent } from './components/group-create/group-create.component';
import { MyGroupsComponent } from './components/my-groups/my-groups.component';
import { ProfileComponent } from './components/profile/profile.component';
import { PostsComponent } from './components/posts/posts.component';
import { MyPrivateGroupsComponent } from './components/my-private-groups/my-private-groups.component';
import { AdminLayoutComponent } from './admin/layout/admin-layout.component';

const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'groups', component: GroupsComponent },
  { path: 'groups/:id', component: GroupDetailComponent },
  { path: 'create-group', component: GroupCreateComponent },
  { path: 'my-groups', component: MyGroupsComponent },
  { path: 'profile', component: ProfileComponent },
  { path: 'posts', component: PostsComponent },
  { path: 'my-private-groups', component: MyPrivateGroupsComponent },
  { path: '', redirectTo: 'groups', pathMatch: 'full' },
  { path: '**', redirectTo: 'groups' },
  {
    path: 'admin',
    component: AdminLayoutComponent,
    children: [
      { path: 'users',    loadChildren: () => import('./admin/users/users.module').then(m => m.UsersModule) },
      { path: 'groups',   loadChildren: () => import('./admin/groups/groups.module').then(m => m.GroupsModule) },
      { path: 'posts',    loadChildren: () => import('./admin/posts/posts.module').then(m => m.PostsModule) },
      { path: 'comments', loadChildren: () => import('./admin/comments/comments.module').then(m => m.CommentsModule) },
      { path: '', redirectTo: 'users', pathMatch: 'full' }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}