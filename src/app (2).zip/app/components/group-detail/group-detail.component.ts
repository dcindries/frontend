import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { GroupsService } from '../../services/groups.service';
import { PostsService } from '../../services/posts.service';
import { AuthService } from '../../services/auth.service';
import { CommentsService } from 'src/app/services/comments.service';

// Declaramos la variable global para Bootstrap
declare var bootstrap: any;

@Component({
  selector: 'app-group-detail',
  templateUrl: './group-detail.component.html',
  styleUrls: ['./group-detail.component.css']
})
export class GroupDetailComponent implements OnInit {
  group: any;
  posts: any[] = [];
  postForm!: FormGroup;
  commentForm!: FormGroup;
  isLoggedIn = false;
  isMember = false;
  isAdmin = false;
  currentUserId = 0;
  errorMessage = '';

  // Cropping properties
  @ViewChild('imageCanvas', { static: false }) imageCanvas!: ElementRef<HTMLCanvasElement>;
  private ctx!: CanvasRenderingContext2D;
  imagePreview: string | ArrayBuffer | null = null;
  isCropping = false;
  cropStartX = 0;
  cropStartY = 0;
  cropEndX = 0;
  cropEndY = 0;
  croppedImage: string | null = null;
  croppingCompleted = false;
  selectedFile: File | null = null;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private fb: FormBuilder,
    private groupsService: GroupsService,
    private postsService: PostsService,
    private authService: AuthService,
    private commentsService: CommentsService
  ) {}

  ngOnInit(): void {
    const idParam = this.route.snapshot.paramMap.get('id');
    if (!idParam) {
      this.errorMessage = 'No se proporcionó el ID del grupo.';
      return;
    }
    const groupId = parseInt(idParam, 10);
    if (isNaN(groupId)) {
      this.errorMessage = 'El ID del grupo no es válido.';
      return;
    }

    // Obtener usuario y luego cargar datos
    this.authService.getUser().subscribe({
      next: user => {
        this.currentUserId = user.id;
        this.isLoggedIn = true;
        this.postForm = this.fb.group({ content: ['', Validators.required] });
        this.commentForm = this.fb.group({ content: ['', Validators.required] });
        this.loadGroup(groupId);
        this.loadPosts(groupId);
      },
      error: err => {
        console.error('Error al obtener usuario:', err);
        this.errorMessage = 'Error de autenticación.';
      }
    });
  }

  loadGroup(id: number): void {
    this.groupsService.getGroupById(id).subscribe({
      next: (res: any) => {
        this.group = res.group;
        this.isMember = res.isMember;
        this.isAdmin = this.currentUserId === this.group.created_by;
      },
      error: err => {
        console.error('Error al cargar el grupo:', err);
        this.errorMessage = 'Error al cargar el grupo.';
      }
    });
  }

  loadPosts(groupId: number): void {
    this.postsService.getPostsByGroup(groupId).subscribe({
      next: data => this.posts = data,
      error: err => {
        console.error('Error al cargar publicaciones:', err);
        this.errorMessage = 'Error al cargar las publicaciones.';
      }
    });
  }

  joinGroup(): void {
    if (this.isMember) return;
    this.groupsService.joinGroup(this.group.id).subscribe({
      next: () => this.loadGroup(this.group.id),
      error: err => {
        console.error('Error al unirse:', err);
        this.errorMessage = err.error?.message || 'Error al unirse al grupo.';
      }
    });
  }

  leaveGroup(): void {
    if (!this.isLoggedIn) {
      this.errorMessage = 'Debes iniciar sesión para abandonar el grupo.';
      return;
    }
    this.groupsService.leaveGroup(this.group.id).subscribe({
      next: (res: any) => {
        if (res.message?.includes('el grupo se eliminó')) {
          this.router.navigate(['/my-private-groups']);
        } else {
          this.loadGroup(this.group.id);
        }
      },
      error: err => {
        console.error('Error al abandonar:', err);
        this.errorMessage = err.error?.message || 'Error al abandonar el grupo.';
      }
    });
  }

  onPostSubmit(): void {
    if (!this.isMember || this.postForm.invalid) {
      this.errorMessage = this.isMember ? 'Escribe algo antes de publicar.' : 'Debes unirte para publicar.';
      return;
    }
    const form = new FormData();
    form.append('content', this.postForm.value.content);
    form.append('group_id', this.group.id.toString());
    if (this.croppedImage) {
      form.append('image', this.dataURLtoBlob(this.croppedImage), 'cropped.png');
    } else if (this.selectedFile) {
      form.append('image', this.selectedFile);
    }
    this.postsService.createPost(form).subscribe({
      next: () => {
        this.postForm.reset();
        this.croppedImage = null;
        this.croppingCompleted = false;
        this.selectedFile = null;
        this.loadPosts(this.group.id);
      },
      error: err => {
        console.error('Error al crear post:', err);
        this.errorMessage = err.error?.message || 'Error al crear el post.';
      }
    });
  }

  onCommentSubmit(postId: number): void {
    if (this.commentForm.invalid) return;
    const data = { post_id: postId, content: this.commentForm.value.content };
    this.commentsService.createComment(data).subscribe({
      next: () => {
        this.commentForm.reset();
        this.loadPosts(this.group.id);
      },
      error: err => {
        console.error('Error al comentar:', err);
        this.errorMessage = err.error?.message || 'Error al comentar.';
      }
    });
  }

  onFileSelected(event: any): void {
    const file = event.target.files?.[0];
    if (file) {
      this.selectedFile = file;
      const reader = new FileReader();
      reader.onload = e => {
        this.imagePreview = e.target?.result || null;
        setTimeout(() => this.initializeCanvas(), 0);
      };
      reader.readAsDataURL(file);
    }
  }

  private initializeCanvas(): void {
    if (!this.imagePreview) return;
    const canvas = this.imageCanvas.nativeElement;
    const img = new Image();
    img.onload = () => {
      canvas.width = img.width;
      canvas.height = img.height;
      this.ctx = canvas.getContext('2d')!;
      this.ctx.drawImage(img, 0, 0);
    };
    img.src = this.imagePreview as string;
  }

  startCrop(e: MouseEvent): void { this.beginCrop(e); }
  drawingCrop(e: MouseEvent): void { this.updateCrop(e); }
  endCrop(e: MouseEvent): void { this.finishCrop(e); }

  private beginCrop(e: MouseEvent): void {
    this.isCropping = true;
    const rect = this.imageCanvas.nativeElement.getBoundingClientRect();
    this.cropStartX = e.clientX - rect.left;
    this.cropStartY = e.clientY - rect.top;
    this.cropEndX = this.cropStartX;
    this.cropEndY = this.cropStartY;
  }

  private updateCrop(e: MouseEvent): void {
    if (!this.isCropping) return;
    const rect = this.imageCanvas.nativeElement.getBoundingClientRect();
    this.cropEndX = e.clientX - rect.left;
    this.cropEndY = e.clientY - rect.top;
    this.redrawCanvas();
  }

  private finishCrop(e: MouseEvent): void {
    if (!this.isCropping) return;
    this.isCropping = false;
    this.redrawCanvas();
  }

  private redrawCanvas(): void {
    if (!this.imagePreview) return;
    const canvas = this.imageCanvas.nativeElement;
    const img = new Image();
    img.onload = () => {
      this.ctx.clearRect(0, 0, canvas.width, canvas.height);
      this.ctx.drawImage(img, 0, 0);
      if (this.isCropping) {
        const x = Math.min(this.cropStartX, this.cropEndX);
        const y = Math.min(this.cropStartY, this.cropEndY);
        const w = Math.abs(this.cropEndX - this.cropStartX);
        const h = Math.abs(this.cropEndY - this.cropStartY);
        this.ctx.strokeStyle = 'red';
        this.ctx.lineWidth = 2;
        this.ctx.strokeRect(x, y, w, h);
      }
    };
    img.src = this.imagePreview as string;
  }

  applyCrop(): void {
    const x = Math.min(this.cropStartX, this.cropEndX);
    const y = Math.min(this.cropStartY, this.cropEndY);
    const w = Math.abs(this.cropEndX - this.cropStartX);
    const h = Math.abs(this.cropEndY - this.cropStartY);
    if (!w || !h) {
      alert('Selecciona un área válida para recortar.');
      return;
    }
    const temp = document.createElement('canvas');
    temp.width = w;
    temp.height = h;
    const tctx = temp.getContext('2d')!;
    const img = new Image();
    img.onload = () => {
      tctx.drawImage(img, x, y, w, h, 0, 0, w, h);
      this.croppedImage = temp.toDataURL('image/png');
      this.croppingCompleted = true;
    };
    img.src = this.imagePreview as string;
  }

  completeImage(): void {
    const canvas = this.imageCanvas.nativeElement;
    this.redrawCanvas();
    this.ctx.strokeStyle = 'green';
    this.ctx.lineWidth = 4;
    this.ctx.strokeRect(0, 0, canvas.width, canvas.height);
    this.croppedImage = canvas.toDataURL('image/png');
    this.croppingCompleted = true;
  }

  private dataURLtoBlob(dataurl: string): Blob {
    const [header, data] = dataurl.split(',');
    const mime = header.match(/:(.*?);/)![1];
    const binary = atob(data);
    let length = binary.length;
    const u8arr = new Uint8Array(length);
    while (length--) {
      u8arr[length] = binary.charCodeAt(length);
    }
    return new Blob([u8arr], { type: mime });
  }

  getRelativeTime(dateStr: string): string {
    if (!dateStr) return '';
    const now = Date.now();
    const then = new Date(dateStr).getTime();
    const diff = now - then;
    const hrs = diff / (1000 * 60 * 60);
    if (hrs < 24) {
      const h = Math.floor(hrs);
      return `hace ${h} hora${h !== 1 ? 's' : ''}`;
    }
    const days = hrs / 24;
    if (days < 30) {
      const d = Math.floor(days);
      return `hace ${d} día${d !== 1 ? 's' : ''}`;
    }
    const months = days / 30;
    const m = Math.floor(months);
    return `hace ${m} mes${m !== 1 ? 'es' : ''}`;
  }

  editPost(post: any): void {
    console.log('Editar post:', post);
    // Implementar lógica de edición si se requiere
  }

  deletePost(post: any): void {
    this.postsService.deletePost(post.id).subscribe({
      next: () => this.loadPosts(this.group.id),
      error: err => {
        console.error('Error al eliminar post:', err);
        this.errorMessage = err.error?.message || 'Error al eliminar el post.';
      }
    });
  }
}