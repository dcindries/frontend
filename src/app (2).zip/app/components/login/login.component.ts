// src/app/components/login/login.component.ts
import { Component, OnInit } from '@angular/core';
import { environment } from '../../../environments/environment';  // ← añadido
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm!: FormGroup;
  errorMessage: string = '';
  baseUrl = environment.baseUrl;   // ← añadido

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required]
    });
  }

  onSubmit(): void {
    if (this.loginForm.invalid) {
      return;
    }
    this.authService.login(this.loginForm.value).subscribe({
      next: (res) => {
        console.log('Login exitoso:', res);
        localStorage.setItem('authToken', res.access_token);
        this.authService.setAuthentication(true);
        this.router.navigate(['/groups']);
      },
      error: (err) => {
        console.error('Error en login:', err);
        this.errorMessage = 'Credenciales incorrectas o error en la conexión.';
      }
    });
  }
}
