import { Component, OnInit } from '@angular/core';
import { environment } from '../../../environments/environment';    // ← ya importado
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  registerForm!: FormGroup;
  errorMessage: string = '';
  selectedFile: File | null = null;
  previewUrl: string | ArrayBuffer | null = null;
  defaultProfile: string = 'assets/default-profile.png';

  apiUrl = environment.apiUrl;
  baseUrl = environment.baseUrl;   

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.registerForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required],
    });
  }

  onFileSelected(event: any): void {
    if (event.target.files && event.target.files.length > 0) {
      this.selectedFile = event.target.files[0];
      const reader = new FileReader();
      reader.onload = () => {
        this.previewUrl = reader.result;
      };
      reader.readAsDataURL(this.selectedFile!);
      console.log('Archivo seleccionado:', this.selectedFile);
    }
  }

  onSubmit(): void {
    if (this.registerForm.invalid) {
      this.errorMessage = 'Por favor, completa el formulario correctamente.';
      return;
    }
    // Crear FormData y enviar la solicitud POST
    const formData = new FormData();
    formData.append('name', this.registerForm.get('name')?.value);
    formData.append('email', this.registerForm.get('email')?.value);
    formData.append('password', this.registerForm.get('password')?.value);
    if (this.selectedFile) {
      formData.append('profile_photo', this.selectedFile);
    }
    
    this.authService.register(formData).subscribe({
      next: (res) => {
        console.log('Registro exitoso:', res);
        this.router.navigate(['/login']);
      },
      error: (err) => {
        console.error('Error en el registro:', err);
        this.errorMessage = err.error?.message || 'Error al registrarse. Intenta nuevamente.';
      }
    });
  }
}
