import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UsersService }   from '../services/user.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
})
export class EditUserComponent implements OnInit {
  form!: FormGroup;   // '!' indica que se inicializa en ngOnInit
  id!: number;

  constructor(
    private fb: FormBuilder,
    private usersService: UsersService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    // Inicializamos el formulario
    this.form = this.fb.group({
      name:  ['', Validators.required],
      email: ['', [Validators.required, Validators.email]]
    });

    // Obtenemos el ID de la URL y cargamos datos
    this.id = Number(this.route.snapshot.paramMap.get('id'));
    this.usersService.get(this.id).subscribe(
      data => this.form.patchValue(data),
      err  => console.error(err)
    );
  }

  onSubmit(): void {
    if (this.form.invalid) return;
    this.usersService.update(this.id, this.form.value).subscribe(
      () => this.router.navigate(['/admin/users']),
      err => console.error(err)
    );
  }
}
