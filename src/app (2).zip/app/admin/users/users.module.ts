// src/app/admin/users/users.module.ts
import { NgModule }            from '@angular/core';
import { CommonModule }        from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { UsersRoutingModule }  from './users-routing.module';

import { ListUserComponent }     from './list-users/list-user.component';
import { CreateUserComponent }   from './create-user/create-user.component';
import { EditUserComponent }     from './edit-user/edit-user.component'; 

@NgModule({
  declarations: [
    ListUserComponent,
    CreateUserComponent,
    EditUserComponent
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    UsersRoutingModule
  ]
})
export class UsersModule {}
