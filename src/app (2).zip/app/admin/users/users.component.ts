// src/app/admin/users/users.module.ts
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UsersRoutingModule } from './users-routing.module';
import { ListUserComponent } from './list-users/list-user.component';
// (importa aquí también CreateUserComponent y EditUserComponent si los usas)

@NgModule({
  declarations: [
    ListUserComponent,
    // CreateUserComponent,
    // EditUserComponent
  ],
  imports: [
    CommonModule,
    UsersRoutingModule
  ]
})
export class UsersModule {}
