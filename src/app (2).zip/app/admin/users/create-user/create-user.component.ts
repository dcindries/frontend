import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UsersService }   from '../services/user.service';
import { Router }         from '@angular/router';

@Component({
  selector: 'app-create-user',
  templateUrl: './create-user.component.html',

})
export class CreateUserComponent implements OnInit {
    form!: FormGroup;   // <-- aquí
  
    constructor(
      private fb: FormBuilder,
      private usersService: UsersService,
      private router: Router
    ) {}
  
    ngOnInit(): void {
      this.form = this.fb.group({
        name:  ['', Validators.required],
        email: ['', [Validators.required, Validators.email]]
      });
    }
  
    onSubmit(): void {
      if (this.form.invalid) return;
      this.usersService.create(this.form.value).subscribe(
        () => this.router.navigate(['/admin/users']),
        err => console.error(err)
      );
    }
  }
  